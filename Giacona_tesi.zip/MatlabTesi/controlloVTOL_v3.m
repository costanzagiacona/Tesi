function u = controlloVTOL_v3(t, params, x, test_id, target)

% Preallocazione
u = zeros(7,1);

% TEST

% -1 : Debug (tutto simbolico)

% 0 : Nessun controllo (solo gravità)

% 1 : Controllo verticale

% 2 : Controllo orizzontale 

% 3 : Controllo orizzontale con momenti 

switch test_id

    case -1
        %debug
        syms u1 u2 u3 u4 u5 u6 u7
        
        % variante in assenza di rotore di coda 
        u = [u1;u2;0;u4;u5;0;0];

    case 0
        % Nessun controllo (solo gravità)
        u = zeros(7,1);

    case 1
        % --- CONTROLLO VERTICALE
        % angoli di roll ,pitch, yaw
        phi = x(7); theta = x(8); psi = x(9);
        p = x(10); q = x(11); r = x(12);
        R = matriceRotazione(phi,theta,psi);
        V_body = [x(4);x(5);x(6)]; % velocità nel body frame
        V_global = R*V_body;
        vx_global = V_global(1); 
        vy_global = V_global(2);
        vz_global = V_global(3);

        % 2. Parametri Obiettivo
        z_des = -10;    vz_des = 0;
        y_des = 0;      vy_des = 0;
        x_des = 0;      vx_des = 0; 
        psi_des = 0;    r_des = 0;  
        % psi_des = 45 * (pi/180);  % ~0.785 radianti

        % 3. Parametri Controllori
        % Z (Quota)
        lambda_z = 2.5; K_z_smc = 60; Phi_z = 0.8;
        % Y (Laterale)
        lambda_y = 0.8; K_y_smc = 15; Phi_y = 1.0;
        % X (Longitudinale)
        lambda_x = 0.8; K_x_smc = 8; Phi_x = 1.0;
        
        % PD Attitudine (Roll & Pitch)
        kp_phi = 40;   kd_phi = 8; 
        kp_theta = 40; kd_theta = 8;

        % PD Yaw (Imbardata)
        kp_psi = 15;   kd_psi = 5; 

        % =========================================================
        %   LOOP Z (QUOTA) 
        % =========================================================
        e_z = z_des - x(3);           
        de_z = vz_des - vz_global;    
        s_z = de_z + lambda_z * e_z;    
        F_grav = params.m * params.g * cos(theta) * cos(phi); 
        F_drag_z = -params.rho*params.s_body_z*params.C_d_z*sign(x(6))*x(6)^2;
        F_lift = -params.C_l*params.rho*params.s*x(4)^2;
        u_smc_z = params.m * lambda_z * de_z + K_z_smc * tanh(s_z / Phi_z);
        % Thrust_req = F_grav + F_drag_z + F_lift - u_smc_z;
        
        % Anche senza conoscere i termini in feedforward, il controllore
        % stabilizza la quota
        Thrust_req = F_grav - u_smc_z;
        if Thrust_req < 1; Thrust_req = 1; end

        % =========================================================
        %   LOOP Y (LATERALE -> ROLLIO)
        % =========================================================
        e_y = y_des - x(2);          
        de_y = vy_des - vy_global;   
        s_y = de_y + lambda_y * e_y; 
        F_y_req = params.m * lambda_y * de_y + K_y_smc * tanh(s_y / Phi_y);
        sin_phi_des = F_y_req / Thrust_req;
        sin_phi_des = max(min(sin_phi_des, 0.5), -0.5); 
        phi_des = asin(sin_phi_des);
        % F_drag_y = params.rho * params.s_body_y * params.C_d_y * sign(x(5)) * x(5)^2;
        e_phi = phi_des - phi;
        de_phi = 0 - p; 
        Moment_roll_req = kp_phi * e_phi + kd_phi * de_phi;

        % =========================================================
        %   LOOP X (LONGITUDINALE -> PITCH) 
        % =========================================================
        e_x = x_des - x(1);
        de_x = vx_des - vx_global;
        s_x = de_x + lambda_x * e_x;
        F_x_req = params.m * lambda_x * de_x + K_x_smc * tanh(s_x / Phi_x);
        sin_theta_des = -F_x_req / Thrust_req;
        sin_theta_des = max(min(sin_theta_des, 0.5), -0.5);
        theta_des = asin(sin_theta_des);
        e_theta = theta_des - theta;
        de_theta = 0 - q;
        Moment_pitch_req = kp_theta * e_theta + kd_theta * de_theta;

        % =========================================================
        %   YAW (IMBARDATA)
        % =========================================================
        % Calcolo errore angolo (normalizzazione [-pi,pi] 
        e_psi = psi_des - psi;
        e_psi = atan2(sin(e_psi), cos(e_psi));
        
        de_psi = r_des - r;
        
        % Richiesta di Momento Yaw
        Moment_yaw_req = kp_psi * e_psi + kd_psi * de_psi;

        % =========================================================
        %   MIXING E ALLOCAZIONE 
        % =========================================================
        theta3_ideal = atan2(((-params.d_tx*params.k)/params.b),1);
        theta3_actual = x(17); 
        
        % --- 1. Mixing Longitudinale (Z + Pitch) ---
        denom_mix = params.d_mx*params.k*sin(theta3_actual) ...
                  - params.d_tx*params.k*sin(theta3_actual) ...
                  + params.b*cos(theta3_actual);
        if abs(denom_mix) < 1e-6; denom_mix = 1e-6; end
        
        numeratore_coda = (params.d_mx * Thrust_req) - Moment_pitch_req;
        omega3_sq = numeratore_coda / denom_mix;
        
        F_tail_z = omega3_sq * params.k * sin(theta3_actual);
        
        % Spinta totale richiesta ai motori anteriori (componente Z)
        F_front_tot_z = Thrust_req - F_tail_z;
        % Protezione per evitare divisioni per zero se i motori anteriori sono spenti
        if F_front_tot_z < 0.1; F_front_tot_z = 0.1; end

        omega_front_sq_base = F_front_tot_z / (2 * params.k);
        
        % --- 2. Mixing Laterale (Roll) ---
        braccio_y = params.d_my;
        delta_omega_sq = Moment_roll_req / (params.k * braccio_y * 2);
        
        omega_dx_sq = omega_front_sq_base - delta_omega_sq; 
        omega_sx_sq = omega_front_sq_base + delta_omega_sq; 
        
        % --- 3. Mixing Yaw (Tilt Differenziale) ---
        delta_tilt_yaw = Moment_yaw_req / (F_front_tot_z * params.d_my);
        
        % Saturazione del tilt per sicurezza (es. max 20 gradi = 0.35 rad)
        max_tilt = 0.35; 
        delta_tilt_yaw = max(min(delta_tilt_yaw, max_tilt), -max_tilt);

        % Assegnazione Tilt (Partendo da pi/2 verticale)
        tilt_1 = pi/2 + delta_tilt_yaw; % Motore DX (1)
        tilt_2 = pi/2 - delta_tilt_yaw; % Motore SX (2)

        % le omega non devono diventare negative
        if omega_dx_sq < 0; omega_dx_sq = 0; end
        if omega_sx_sq < 0; omega_sx_sq = 0; end
        if omega3_sq < 0; omega3_sq = 0; end

        u(1) = sqrt(omega_dx_sq);    
        u(2) = sqrt(omega_sx_sq);    
        u(3) = sqrt(omega3_sq);      
        u(4) = tilt_1; 
        u(5) = tilt_2; 
        u(6) = theta3_ideal; 
        u(7) = -pi/2;

    case 2
        % =========================================================================
        %  Controllo orizzontale
        %  =========================================================================
    
        % ================================================
        % 1. ESTRAZIONE E PREPARAZIONE STATI
        % Stati angolari e ratei
        % =================================================
        phi = x(7); theta = x(8); psi = x(9);
        p = x(10);  q = x(11);    r = x(12);
        
        % =================================================
        % Calcolo Velocità nel riferimento Globale (NED)
        % =================================================
        R = matriceRotazione(phi, theta, psi);
        V_glob = R * [x(4); x(5); x(6)];
        vx_global = V_glob(1); 
        vz_global = V_glob(3);
        
        % =================================================
        % Lettura Integrali 
        % =================================================
        if length(x) >= 29
            int_err_v     = x(27); % Integrale Velocità
            int_err_theta = x(28); % Integrale Pitch
            int_err_z     = x(29);
        else
            int_err_v = 0; int_err_theta = 0; int_err_z = 0;
        end
        
        % =================================================
        % 2. DEFINIZIONE SETPOINT (Guida)
        % =================================================
        % Target operativi per la crociera
        z_des     = target(3);       % Quota target (negativa in NED)
        vx_des    = target(1); % Velocità target (es. 30 m/s)
        theta_des = target(2); % Pitch target (solitamente 0° in crociera)
        phi_des = 0;
        psi_des = 0;

        % =================================================
        % 3. CONTROLLO QUOTA (Loop Z - Outer Loop)
        % =================================================
        % Calcolo errori di posizione e velocità verticale
        e_z  = z_des - x(3);
        de_z = 0 - vz_global;
        
        % PID Quota
        kp_z = 4.0; 
        kd_z = 6.0; 
        ki_z = 0.5;
        az_cmd = kp_z * e_z + kd_z * de_z + ki_z * int_err_z;
        
        % =================================================
        % --- Feedforward Aerodinamico (ALA) ---
        % =================================================
        % Calcolo portanza generata dall'ala (negativa in NED perché verso l'alto)
        % L = 0.5 * rho * S * Cl * V^2
        F_lift_wing = -0.5 * params.rho * params.s * params.C_l * vx_global^2;
        
        % Forza verticale richiesta ai motori (F = m*a - L_ala)
        % Se l'ala sostiene tutto il peso, Fz_req tende a 0.
        Fz_req = params.m * (params.g - az_cmd) + F_lift_wing;
        
        % [FIX FISICO]: Gestione Portanza Eccessiva
        % Se l'ala genera troppa portanza (Fz_req < 0), permettiamo ai motori 
        % di spingere verso il basso (fino a -40N) per non salire incontrollati.
        if Fz_req < -80; Fz_req = -80; end 
    
        % =================================================
        % 4. CONTROLLO VELOCITÀ (Loop X - Outer Loop)
        % =================================================
        e_v = vx_des - vx_global;
        
        % PID Velocità
        kp_v = 8.0; 
        ki_v = 4.0; 
        
        % --- Feedforward Aerodinamico (DRAG) ---
        % D = 0.5 * rho * S * Cd * V^2
        F_drag = 0.5 * params.rho * params.s * params.C_d * vx_global^2;
        
        % Forza orizzontale richiesta (deve vincere Drag + Inerzia)
        Fx_req = F_drag + kp_v * e_v + ki_v * int_err_v;
        
        % per evitare singolarità matematiche
        if Fx_req < 0.1; Fx_req = 0.1; end
       
        % =================================================
        % 5. STRATEGIA VETTORIALE (Thrust Vectoring)
        % =================================================
        % Calcolo dell'angolo di spinta ideale nel riferimento GLOBALE
        alpha_ideal = atan2(Fz_req, Fx_req);
        
        % Limitazione dell'angolo di tilt (Safety)
        % se permettiamo un inclinazione fino a 90°, il drone cade
        max_tilt_safe = deg2rad(45); 
        alpha_limited = max(-max_tilt_safe, min(max_tilt_safe, alpha_ideal));
        
        % Sottraiamo il pitch corrente (theta) per ottenere l'angolo relativo ai servi.
        % Se il drone alza il naso (theta > 0), i servi ruotano giù per compensare.
        alpha_servo_base = alpha_limited - theta;
    
        % =================================================
        % 6. CONTROLLO DI ASSETTO (Inner Loop)
        % =================================================

        % =================================================
        % --- A. PITCH (Beccheggio) ---
        % =================================================
        e_theta  = theta_des - theta;
        de_theta = 0 - q;
        
        kp_th = 2; 
        kd_th = 0.3; 
        ki_th = 1.5;  
        
        % L'output del PID pitch è un angolo correttivo da sommare al tilt base
        u_pitch_angle = kp_th * e_theta + kd_th * de_theta + ki_th * int_err_theta;
        
        % =================================================
        % --- B. ROLL (Rollio) ---
        % =================================================  
        kp_phi = 0.20;  
        kd_phi = 0.10; 

        u_roll_angle = kp_phi * (phi_des - phi) + kd_phi * (0 - p);
        
        
        % =================================================
        % --- C. YAW (Imbardata) ---
        % =================================================      
        kp_psi = 10;  
        kd_psi = 2.5;  

        u_yaw_thrust = kp_psi * (psi_des - psi) + kd_psi * (0 - r);
    
        % =================================================
        % 7. MIXER / ALLOCAZIONE ATTUATORI
        % =================================================        
        % Spinta Totale richiesta (somma vettoriale)
        T_tot = sqrt(Fx_req^2 + Fz_req^2);
  
        
        % Angoli Servo (Tilt Collettivo + Pitch Corr + Diff Roll)
        ts1 = alpha_servo_base + u_pitch_angle - u_roll_angle; 
        ts2 = alpha_servo_base + u_pitch_angle + u_roll_angle; 
        
        % Spinte Motori (Spinta Base -/+ Diff Yaw)
        T1 = (T_tot / 2) - u_yaw_thrust; 
        T2 = (T_tot / 2) + u_yaw_thrust; 
        
        % 8. SATURAZIONE E OUTPUT
        
        % Saturazione fisica dei servi (limiti meccanici)
        % Non voglio che i rotori si inclinino all'infinito
        ts1 = max(deg2rad(-30), min(deg2rad(80), ts1));
        ts2 = max(deg2rad(-30), min(deg2rad(80), ts2));
        
        % =================================================
        % Assegnazione al vettore di controllo u
        % =================================================
        u(1) = sqrt(max(0, T1) / params.k);
        u(2) = sqrt(max(0, T2) / params.k);
        u(3) = 0; % Motore posteriore spento
        
        u(4) = ts1; 
        u(5) = ts2;
        u(6) = 0;   
        u(7) = 0;   

    case 3
        % =========================================================================
        %  Controllo orizzontale
        %  Uscite loop interno: momenti su x, y e z
        % =========================================================================
    
        % ================================================
        % 1. ESTRAZIONE E PREPARAZIONE STATI
        % Stati angolari e ratei
        % =================================================
        phi = x(7); theta = x(8); psi = x(9);
        p = x(10);  q = x(11);    r = x(12);
        
        % =================================================
        % Calcolo Velocità nel riferimento Globale (NED)
        % =================================================
        R = matriceRotazione(phi, theta, psi);
        V_glob = R * [x(4); x(5); x(6)];
        vx_global = V_glob(1); 
        vz_global = V_glob(3);
        
        % =================================================
        % Lettura Integrali 
        % =================================================
        if length(x) >= 29
            int_err_v     = x(27); % Integrale Velocità
            int_err_theta = x(28); % Integrale Pitch
            int_err_z     = x(29);
        else
            int_err_v = 0; int_err_theta = 0; int_err_z = 0;
        end
        
        % =================================================
        % 2. DEFINIZIONE SETPOINT (Guida)
        % =================================================
        % Target operativi per la crociera
        z_des     = target(3);  % -10
        vx_des    = target(1);  % 25 m/s
        theta_des = target(2);  % 0°
        phi_des = 0;
        psi_des = 0;
        
    
        % =================================================
        % 3. CONTROLLO QUOTA (Loop Z - Outer Loop)
        % =================================================
        % Calcolo errori di posizione e velocità verticale
        e_z  = z_des - x(3);
        de_z = 0 - vz_global;
        
        % PID Quota
        kp_z = 4.0; 
        kd_z = 6.0; 
        ki_z = 0.5;
        az_cmd = kp_z * e_z + kd_z * de_z + ki_z * int_err_z;
        
        % =================================================
        % --- Feedforward Aerodinamico (ALA) ---
        % =================================================
        % Calcolo portanza generata dall'ala (negativa in NED perché verso l'alto)
        % L = 0.5 * rho * S * Cl * V^2
        F_lift_wing = -0.5 * params.rho * params.s * params.C_l * vx_global^2;
        
        % Forza verticale richiesta ai motori (F = m*a - L_ala)
        % Se l'ala sostiene tutto il peso, Fz_req tende a 0.
        Fz_req = params.m * (params.g - az_cmd) + F_lift_wing;
        
        % [FIX FISICO]: Gestione Portanza Eccessiva
        % Se l'ala genera troppa portanza (Fz_req < 0), permettiamo ai motori 
        % di spingere verso il basso (fino a -40N) per non salire incontrollati.
        if Fz_req < -80; Fz_req = -80; end 
    
        % =================================================
        % 4. CONTROLLO VELOCITÀ (Loop X - Outer Loop)
        % =================================================
        e_v = vx_des - vx_global;
        
        % PID Velocità
        kp_v = 8.0; 
        ki_v = 4.0;
        
        % --- Feedforward Aerodinamico (DRAG) ---
        % D = 0.5 * rho * S * Cd * V^2
        F_drag = 0.5 * params.rho * params.s * params.C_d * vx_global^2;
        
        % Forza orizzontale richiesta 
        Fx_req = F_drag + kp_v * e_v + ki_v * int_err_v;
        
        % per evitare singolarità matematiche
        if Fx_req < 0.1; Fx_req = 0.1; end
  
        % =================================================
        % 5. STRATEGIA VETTORIALE (Thrust Vectoring)
        % =================================================
        % Calcolo dell'angolo di spinta ideale nel riferimento GLOBALE
        alpha_ideal = atan2(Fz_req, Fx_req);
        
        % Limitazione dell'angolo di tilt (Safety)
        max_tilt_safe = deg2rad(45); 
        alpha_limited = max(-max_tilt_safe, min(max_tilt_safe, alpha_ideal));
        
        % Sottraiamo il pitch corrente (theta) per ottenere l'angolo relativo ai servi.
        % Se il drone alza il naso (theta > 0), i servi ruotano giù per compensare.
        alpha_servo_base = alpha_limited - theta;
    
        % =================================================
        % 6. CONTROLLO DI ASSETTO (Inner Loop)
        % =================================================

        % =================================================
        % --- A. PITCH (Beccheggio) ---
        % =================================================
        e_theta  = theta_des - theta;
        de_theta = 0 - q;
        
        kp_th = 40;
        kd_th = 10;
        ki_th = 20;  
        
        M_y = kp_th * e_theta + kd_th * de_theta + ki_th * int_err_theta;
        
        % =================================================
        % --- B. ROLL (Rollio) ---
        % =================================================

        kp_phi = 10; 
        kd_phi = 3;  

        M_x = kp_phi * (phi_des - phi) + kd_phi * (0 - p);
             
        % =================================================
        % --- C. YAW (Imbardata) ---
        % =================================================
        
        kp_psi = 5; 
        kd_psi = 2;  

        M_z = kp_psi * (psi_des - psi) + kd_psi * (0 - r);
    
        % =================================================
        % 7. MIXER
        % =================================================
        
        % Spinta Totale richiesta
        T_tot = sqrt(Fx_req^2 + Fz_req^2);

        % 1. Calcolo Angolo per il Pitch 
        % My = dmx * T * sin(theta)  ->  sin(theta) = My / (dmx * T)
        u_pitch_angle = M_y / (params.d_mx * T_tot);
        
        % 1. ROLLIO: Inversione Mx = dmy * Ttot * delta
        % Calcolo angolo differenziale (delta)
        u_roll_angle = M_x / (T_tot * params.d_my);
        
        % 2. IMBARDATA: Inversione Mz = dmy * (T2 - T1)
        % Calcolo spinta differenziale (Delta T)
        u_yaw_thrust = M_z / (params.d_my);
        
        % 3. CALCOLO FINALE COMANDI
        
        % Angoli Servo (Tilt Collettivo + Pitch Corr + Diff Roll)
        ts1 = alpha_servo_base + u_pitch_angle - u_roll_angle; 
        ts2 = alpha_servo_base + u_pitch_angle + u_roll_angle; 
        
        % Spinte Motori (Spinta Base -/+ Diff Yaw)
        T1 = (T_tot / 2) - u_yaw_thrust; 
        T2 = (T_tot / 2) + u_yaw_thrust; 
        
        % 8. SATURAZIONE E OUTPUT
        
        % Saturazione fisica dei servi (limiti meccanici)
        ts1 = max(deg2rad(-30), min(deg2rad(80), ts1));
        ts2 = max(deg2rad(-30), min(deg2rad(80), ts2));
        
        % =================================================
        % Assegnazione al vettore di controllo u
        % =================================================
        u(1) = sqrt(max(0, T1) / params.k);
        u(2) = sqrt(max(0, T2) / params.k);
        u(3) = 0; % Motore posteriore spento
        
        u(4) = ts1; 
        u(5) = ts2;
        u(6) = 0;   
        u(7) = 0;   
        

    otherwise
        fprintf("Controllo selezionato non trovato\n");
        % Se richiami altri case non definiti qui, metti un default
        u = zeros(7,1);
end
end
